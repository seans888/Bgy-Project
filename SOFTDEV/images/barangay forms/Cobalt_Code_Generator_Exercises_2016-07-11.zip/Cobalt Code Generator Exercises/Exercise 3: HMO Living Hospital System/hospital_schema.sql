-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2016 at 10:27 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital_schema`
--

-- --------------------------------------------------------

--
-- Table structure for table `cobalt_reporter`
--

CREATE TABLE IF NOT EXISTS `cobalt_reporter` (
  `module_name` varchar(255) NOT NULL,
  `report_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `show_field` blob NOT NULL,
  `operator` blob NOT NULL,
  `text_field` blob NOT NULL,
  `sum_field` blob NOT NULL,
  `count_field` blob NOT NULL,
  `group_field` blob NOT NULL,
  PRIMARY KEY (`module_name`,`report_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `disease_history`
--

CREATE TABLE IF NOT EXISTS `disease_history` (
  `disease_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `medical_professional_id` int(11) DEFAULT NULL,
  `disease` varchar(255) NOT NULL,
  `disease_status` varchar(255) DEFAULT NULL,
  `is_active` varchar(255) NOT NULL,
  `is_infectious` varchar(255) NOT NULL,
  `severity` varchar(255) DEFAULT NULL,
  `is_allergic` varchar(255) NOT NULL,
  `is_pregnancy_risk` varchar(255) NOT NULL,
  `diagnosis_date` date DEFAULT NULL,
  `date_healed` date DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `allergy_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`disease_history_id`),
  KEY `fk_disease_history_patient1_idx` (`patient_id`),
  KEY `fk_disease_history_medical_professional1_idx` (`medical_professional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `hospital_inventory`
--

CREATE TABLE IF NOT EXISTS `hospital_inventory` (
  `hospital_inventory_id` int(11) NOT NULL AUTO_INCREMENT,
  `inventory_code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inventory_type` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hospital_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medical_professional`
--

CREATE TABLE IF NOT EXISTS `medical_professional` (
  `medical_professional_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `license_id_code` varchar(255) DEFAULT NULL,
  `medical_professional_info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`medical_professional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medical_professional_schedule`
--

CREATE TABLE IF NOT EXISTS `medical_professional_schedule` (
  `medical_professional_schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `medical_professional_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `day` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  PRIMARY KEY (`medical_professional_schedule_id`),
  KEY `fk_medical_professional_schedule_medical_professional1_idx` (`medical_professional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medical_professional_specialty`
--

CREATE TABLE IF NOT EXISTS `medical_professional_specialty` (
  `medical_professional_specialty_id` int(11) NOT NULL AUTO_INCREMENT,
  `medical_professional_id` int(11) NOT NULL,
  `specialty_id` int(11) NOT NULL,
  PRIMARY KEY (`medical_professional_specialty_id`),
  KEY `fk_medical_professional_specialty_medical_professional1_idx` (`medical_professional_id`),
  KEY `fk_medical_professional_specialty_specialty1_idx` (`specialty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medical_professional_type`
--

CREATE TABLE IF NOT EXISTS `medical_professional_type` (
  `medical_professional_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `medical_professional_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`medical_professional_type_id`),
  KEY `fk_medical_professional_type_lookup_medical_professional1_idx` (`medical_professional_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `medication_history`
--

CREATE TABLE IF NOT EXISTS `medication_history` (
  `medication_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `hospital_inventory_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `medication_status` varchar(255) NOT NULL,
  `adverse_reactions` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`medication_history_id`),
  KEY `fk_medication_history_patient1_idx` (`patient_id`),
  KEY `fk_medication_history_hospital_inventory1_idx` (`hospital_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `critical_information` varchar(255) DEFAULT NULL,
  `civil_status` varchar(255) DEFAULT NULL,
  `insurance` varchar(255) DEFAULT NULL,
  `blood_type` varchar(255) DEFAULT NULL,
  `socioeconomic_class` varchar(255) DEFAULT NULL,
  `education_level` varchar(255) DEFAULT NULL,
  `housing_condition` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `address_province` varchar(255) DEFAULT NULL,
  `address_city` varchar(255) DEFAULT NULL,
  `address_country` varchar(255) DEFAULT NULL,
  `address_street` varchar(255) DEFAULT NULL,
  `address_zipcode` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(255) DEFAULT NULL,
  `contact_mobile` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `specialty`
--

CREATE TABLE IF NOT EXISTS `specialty` (
  `specialty_id` int(11) NOT NULL AUTO_INCREMENT,
  `specialty_code` varchar(255) NOT NULL,
  `specialty_name` varchar(255) NOT NULL,
  PRIMARY KEY (`specialty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `surgery_history`
--

CREATE TABLE IF NOT EXISTS `surgery_history` (
  `surgery_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `surgeon_medical_professional_id` int(11) DEFAULT NULL,
  `anesthesist_medical_professional_id` int(11) DEFAULT NULL,
  `hospital_inventory_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_condition` varchar(255) DEFAULT NULL,
  `urgency` varchar(255) DEFAULT NULL,
  `asa_ps` varchar(255) DEFAULT NULL,
  `rcri` varchar(255) DEFAULT NULL,
  `mallampati_score` varchar(255) DEFAULT NULL,
  `has_risk_massive_bleeding` varchar(255) NOT NULL,
  `has_pulse_oximeter` varchar(255) NOT NULL,
  `has_surgical_site_marking` varchar(255) NOT NULL,
  `has_antibiotic_prophylaxis` varchar(255) NOT NULL,
  `has_sterility_confirmed` varchar(255) NOT NULL,
  `procedure` varchar(255) DEFAULT NULL,
  `anesthesia` varchar(255) DEFAULT NULL,
  `details_incidents` varchar(255) DEFAULT NULL,
  `surgery_start_date` date DEFAULT NULL,
  `surgery_end_date` date DEFAULT NULL,
  `surgery_status` varchar(255) NOT NULL,
  PRIMARY KEY (`surgery_history_id`),
  KEY `fk_surgery_history_patient1_idx` (`patient_id`),
  KEY `fk_surgery_history_medical_professional1_idx` (`surgeon_medical_professional_id`),
  KEY `fk_surgery_history_medical_professional2_idx` (`anesthesist_medical_professional_id`),
  KEY `fk_surgery_history_hospital_inventory1_idx` (`hospital_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `system_log`
--

CREATE TABLE IF NOT EXISTS `system_log` (
  `entry_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `action` mediumtext NOT NULL,
  `module` varchar(255) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`setting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `system_skins`
--

CREATE TABLE IF NOT EXISTS `system_skins` (
  `skin_id` int(11) NOT NULL AUTO_INCREMENT,
  `skin_name` varchar(255) NOT NULL,
  `header` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `master_css` varchar(255) NOT NULL,
  `colors_css` varchar(255) NOT NULL,
  `fonts_css` varchar(255) NOT NULL,
  `override_css` varchar(255) NOT NULL,
  `icon_set` varchar(255) NOT NULL,
  PRIMARY KEY (`skin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `iteration` int(11) NOT NULL,
  `method` varchar(255) NOT NULL,
  `person_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `skin_id` int(11) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_links`
--

CREATE TABLE IF NOT EXISTS `user_links` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `descriptive_title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `passport_group_id` int(11) NOT NULL,
  `show_in_tasklist` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=165 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_passport`
--

CREATE TABLE IF NOT EXISTS `user_passport` (
  `username` varchar(255) NOT NULL,
  `link_id` int(11) NOT NULL,
  PRIMARY KEY (`username`,`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_passport_groups`
--

CREATE TABLE IF NOT EXISTS `user_passport_groups` (
  `passport_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `passport_group` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`passport_group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_role_links`
--

CREATE TABLE IF NOT EXISTS `user_role_links` (
  `role_id` int(11) NOT NULL,
  `link_id` int(11) NOT NULL,
  PRIMARY KEY (`role_id`,`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_history`
--

CREATE TABLE IF NOT EXISTS `vaccination_history` (
  `vaccination_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `medical_professional_id` int(11) DEFAULT NULL,
  `hospital_inventory_id` int(11) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `vaccination_date` date NOT NULL,
  `observations` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`vaccination_history_id`),
  KEY `fk_vaccination_history_patient1_idx` (`patient_id`),
  KEY `fk_vaccination_history_medical_professional1_idx` (`medical_professional_id`),
  KEY `fk_vaccination_history_hospital_inventory1_idx` (`hospital_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `disease_history`
--
ALTER TABLE `disease_history`
  ADD CONSTRAINT `fk_disease_history_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_disease_history_medical_professional1` FOREIGN KEY (`medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `medical_professional_schedule`
--
ALTER TABLE `medical_professional_schedule`
  ADD CONSTRAINT `fk_medical_professional_schedule_medical_professional1` FOREIGN KEY (`medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `medical_professional_specialty`
--
ALTER TABLE `medical_professional_specialty`
  ADD CONSTRAINT `fk_medical_professional_specialty_medical_professional1` FOREIGN KEY (`medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_medical_professional_specialty_specialty1` FOREIGN KEY (`specialty_id`) REFERENCES `specialty` (`specialty_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `medical_professional_type`
--
ALTER TABLE `medical_professional_type`
  ADD CONSTRAINT `fk_medical_professional_type_lookup_medical_professional1` FOREIGN KEY (`medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `medication_history`
--
ALTER TABLE `medication_history`
  ADD CONSTRAINT `fk_medication_history_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_medication_history_hospital_inventory1` FOREIGN KEY (`hospital_inventory_id`) REFERENCES `hospital_inventory` (`hospital_inventory_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `surgery_history`
--
ALTER TABLE `surgery_history`
  ADD CONSTRAINT `fk_surgery_history_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_surgery_history_medical_professional1` FOREIGN KEY (`surgeon_medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_surgery_history_medical_professional2` FOREIGN KEY (`anesthesist_medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_surgery_history_hospital_inventory1` FOREIGN KEY (`hospital_inventory_id`) REFERENCES `hospital_inventory` (`hospital_inventory_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `vaccination_history`
--
ALTER TABLE `vaccination_history`
  ADD CONSTRAINT `fk_vaccination_history_patient1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vaccination_history_medical_professional1` FOREIGN KEY (`medical_professional_id`) REFERENCES `medical_professional` (`medical_professional_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vaccination_history_hospital_inventory1` FOREIGN KEY (`hospital_inventory_id`) REFERENCES `hospital_inventory` (`hospital_inventory_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
