<?php
//Default whitelist of allowed file extensions for file uploads
$arr_good_extensions = array('jpg','jpeg','gif','bmp','png',
                             'doc','docx','xls','xlsx','ppt','pptx',
                             'odt','ods','odp','txt','rtf','pdf',
                             'zip','rar','7z','bz2','tar','gz'
                             );
