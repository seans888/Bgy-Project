<?php

?>

		<footer class="foot">
			<p class="copyrights">&copy; &nbsp;&nbsp; Copyright. 2016 &nbsp;|&nbsp; Barangay System</p>

	


		</footer>
</body>
</html>
