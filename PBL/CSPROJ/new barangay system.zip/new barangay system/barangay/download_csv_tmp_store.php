<?php
require 'path.php';
init_cobalt('ALLOW_ALL');
$valid_directory = TMP_DIRECTORY . '/' . TMP_CSV_STORE;
require 'components/download.php';
