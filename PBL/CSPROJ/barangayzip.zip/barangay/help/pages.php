<?php
//List of modules (tables) for the table of contents to show
//The format is doc_subclass_name => doc_dir_name
$content_pages = array(
        'barangay_doc'=>'barangay',
        'bulletin_doc'=>'bulletin',
        'city_doc'=>'city',
        'notification_doc'=>'notification',
        'official_doc'=>'official',
        'province_doc'=>'province',
        'region_doc'=>'region',
        'request_doc'=>'request',
        'request_has_requirement_doc'=>'request_has_requirement',
        'requirement_doc'=>'requirement',
        'service_doc'=>'service',
        'validate_doc'=>'validate',
);