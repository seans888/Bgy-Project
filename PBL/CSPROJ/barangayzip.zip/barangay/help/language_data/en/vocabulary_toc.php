<?php
$project_name = GLOBAL_PROJECT_NAME;
$toc_title = 'Documentation | Table of Contents';