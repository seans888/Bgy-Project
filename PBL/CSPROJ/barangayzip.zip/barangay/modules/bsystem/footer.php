<?php

?>

		<footer class="footer">
			<p class="copyrights">&copy; &nbsp;&nbsp; Copyright. 2016 &nbsp;|&nbsp; Barangay System</p>

			<div class="ftnav">
				<a class="icon" href="https://www.facebook.com/"><img src="images/facebook.png"></img></a>
				<a class="icon" href="https://www.twitter.com/"><img src="images/twitter.png"></img></a>
				<a class="icon" href="https://www.tumblr.com/"><img src="images/tumblr.png"></img></a>
				<a class="icon" href="https://www.youtube.com/"><img src="images/youtube.png"></img></a>
				</div>


		</footer>
</body>
</html>
