<?php
require 'base_validation_class.php';
class validation extends base_validation
{

}