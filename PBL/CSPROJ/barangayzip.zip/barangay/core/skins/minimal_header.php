<!DOCTYPE html>
<html>
<head>
    <title> <?php echo GLOBAL_PROJECT_NAME;?> - Powered by Cobalt</title>
    <link href="/<?php echo BASE_DIRECTORY;?>/css/<?php echo $_SESSION['master_css'];?>" rel="stylesheet" type="text/css">
    <meta http-equiv="content-type" content="text/html; charset=<?php echo MULTI_BYTE_ENCODING; ?>" />
</head>
<body>
