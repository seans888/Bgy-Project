<?php
	require 'path.php';
	init_cobalt();
	$page_title='Barangay System';
	$stylesheet_link='style';
	$rstylesheet_link='responsive';
	require 'header1.php';
?>
<main>
<div class = "wrapper">
	<div class="block-body">
		<center><h1>Contact Us</h1><br></center>

		<div class="float-box">
			<img class="img" src="images/mila1.png"></img>
			<center><h3>Kamila Lagman</h3></center>
			<center><h5>Project Manager</h5></center>
			<center><p>krlagman@student.apc.edu.ph</p></center>
		</div>
		<div class="float-box">
			<img class="img" src="images/jhonel1.png"></img>
			<center><h3>Jhonel Deluna</h3></center>
			<center><h5>Project Developer</h5></center>
			<center><p>hrdeluna@student.apc.edu.ph</p></center>
		</div>
		<div class="float-box">
			<img class="img" src="images/warren1.png"></img>
			<center><h3>David Warren Arcellana</h3></center>
			<center><h5>Project Developer</h5></center>
			<center><p>diarcellana@student.apc.edu.ph</p></center>
		</div>
		<div class="float-box">
			<img class="img" src="images/daren.png"></img>
			<center><h3>Daren Mar Cabral</h3></center>
			<center><h5>Project Developer</h5></center>
			<center><p>dgcabral@student.apc.edu.ph</p></center>
		</div>
		<div class="float-box">
			<img class="img" src="images/logo.png"></img>
			<center><h3>Christian Ansel  Sevilla</h3></center>
			<center><h5>Project Developer</h5></center>
			<center><p>cesevilla@student.apc.edu.ph</p></center>	
		</div>
	</div>
</div>
</main>

<?php
	require 'footer.php'
?>
