<?php
require 'base_char_set_class.php';
class char_set extends base_char_set
{

}