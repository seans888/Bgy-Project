<?php
$how_to_add_intro = 'Upang makadagdag ng bagond rekord sa ' . $module_name . ' module';
$how_to_add_required = 'kailangang lagyan ng laman ang mga sumusunod:';
$how_to_add_optional = 'Maaari ring lagyan ng laman ang mga sumusunod kung nararapat, ngunit sila ay opsyonal lamang:';

$how_to_add_working_with_fields_0 = 'Bigyang pansin po ang mga sumusunod na impormasyon tungkol sa module na ito:';
$how_to_add_working_with_fields_1 = 'Ang ';
$how_to_add_working_with_fields_2 = 'ay tatanggap lang ng hanggang';
$how_to_add_working_with_fields_3 = 'na titik.';
$how_to_add_working_with_fields_4 = 'ay wala namang limit sa tatanggaping haba ng input.';

$how_to_add_allowed_chars_0 = 'Maaaring may limitasyon sa mga titik na tatanggapin ang mga kahon dito. Ang mga limitasyong ito ay ang mga sumusunod:';
$how_to_add_allowed_chars_1 = 'Ang ';
$how_to_add_allowed_chars_2 = 'ay tatanggap ng kahit anong titik; walang titik ang pinagbawal.';
$how_to_add_allowed_chars_3 = 'ay tatanggap lamang ng mga sumusunod na titik: ';
$how_to_add_allowed_chars_4 = 'Lahat ng titik ay tatanggapin.';

