<?php
	$page_title='Barangay System';
	$stylesheet_link='style';

	require 'header1.php';
?>
<main>
	<center><div class="register_layout">
	
	</div></center>


</main>

<?php
	require 'footer.php';
?>