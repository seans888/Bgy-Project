<?php
	$page_title='Barangay System';
	$stylesheet_link='style';
	require 'header1.php';
?>

<?php
	require 'footer.php';
?>